﻿namespace PlayersAndMonsters
{
    internal class MuseElf : Elf
    {
        public MuseElf(string username, int level) : base (username, level)
        {
        }
    }
}
